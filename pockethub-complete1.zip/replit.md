# Multi-Tool Application

## Overview

Multi-Tool is a React-based single-page application that combines financial calculators and personal productivity tools. The application features a mobile-first design with bottom navigation, offering calculators for age, EMI, percentage, GST, and SIP calculations, along with todo list management, expense tracking, and debt tracking functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The client-side is built with React and TypeScript, using modern React patterns and hooks. The architecture follows a component-based approach with:

- **Component Structure**: Organized into feature-specific folders (calculators, todo, expenses, debts) under a shared components directory
- **UI Components**: Utilizes shadcn/ui design system built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: React Query (TanStack Query) for server state management and built-in React hooks for local state
- **Routing**: Simple client-side routing with Wouter library
- **Build System**: Vite as the build tool and development server with hot module replacement

### Backend Architecture

The server follows a REST API pattern built with Express.js:

- **API Design**: RESTful endpoints organized by resource type (todos, expenses, debts)
- **Route Structure**: Centralized route registration with modular endpoint definitions
- **Data Storage**: Abstracted storage interface allowing for different implementations (currently in-memory storage)
- **Middleware**: Request logging, JSON parsing, and error handling middleware
- **Development Integration**: Vite middleware integration for seamless full-stack development

### Database Design

The application uses Drizzle ORM with PostgreSQL schema definitions:

- **Schema Structure**: Separate tables for users, todos, expenses, and debts with appropriate relationships
- **Type Safety**: Zod validation schemas generated from Drizzle table definitions
- **Migration Support**: Drizzle Kit for database migrations and schema management
- **Connection**: Neon Database serverless PostgreSQL for production deployment

### UI/UX Architecture

Mobile-first responsive design with:

- **Navigation**: Bottom tab navigation for mobile experience
- **Layout**: Card-based interface with consistent spacing and typography
- **Theme System**: CSS custom properties for theming with light/dark mode support
- **Accessibility**: Radix UI components ensure proper ARIA attributes and keyboard navigation
- **Typography**: Inter font family with systematic font sizing and spacing

### Development Workflow

- **Development Server**: Integrated Vite dev server with Express backend
- **Type Safety**: Full TypeScript coverage across client, server, and shared code
- **Code Organization**: Shared schema definitions between client and server
- **Build Process**: Separate build outputs for client (static assets) and server (Node.js bundle)

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database toolkit and query builder
- **Drizzle Kit**: Database migration and introspection tools

### UI Framework & Styling
- **Radix UI**: Headless UI component library for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Pre-built component library based on Radix and Tailwind
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking across the application
- **React Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing
- **date-fns**: Date manipulation and formatting utilities

### Runtime & Server
- **Express.js**: Web application framework for Node.js
- **Node.js**: JavaScript runtime environment
- **ESBuild**: Fast JavaScript bundler for server-side code

The application is designed to be easily deployable to platforms like Replit with minimal configuration, using environment variables for database connections and supporting both development and production builds.