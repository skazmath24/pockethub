import { useState } from "react";
import MobileHeader from "@/components/layout/mobile-header";
import BottomNavigation from "@/components/layout/bottom-navigation";
import AgeCalculator from "@/components/calculators/age-calculator";
import EMICalculator from "@/components/calculators/emi-calculator";
import PercentageCalculator from "@/components/calculators/percentage-calculator";
import GSTCalculator from "@/components/calculators/gst-calculator";
import SIPCalculator from "@/components/calculators/sip-calculator";
import TodoList from "@/components/todo/todo-list";
import ExpenseTracker from "@/components/expenses/expense-tracker";
import DebtTracker from "@/components/debts/debt-tracker";

export type TabType = "calculators" | "todo" | "expenses" | "debts";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>("calculators");

  const renderContent = () => {
    switch (activeTab) {
      case "calculators":
        return (
          <div className="px-4 py-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">Calculators</h2>
              <p className="text-muted-foreground">Financial and utility calculators for daily use</p>
            </div>
            
            <div className="calculator-grid">
              <AgeCalculator />
              <EMICalculator />
              <PercentageCalculator />
              <GSTCalculator />
              <SIPCalculator />
            </div>
          </div>
        );
      case "todo":
        return <TodoList />;
      case "expenses":
        return <ExpenseTracker />;
      case "debts":
        return <DebtTracker />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <MobileHeader />
      <main className="pb-20">
        {renderContent()}
      </main>
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
