import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Expense } from "@shared/schema";
import { format } from "date-fns";

const categories = [
  "Food & Dining",
  "Transportation",
  "Shopping",
  "Entertainment",
  "Bills & Utilities",
  "Healthcare",
  "Other",
];

const categoryColors: Record<string, string> = {
  "Food & Dining": "bg-red-500",
  "Transportation": "bg-blue-500",
  "Shopping": "bg-green-500",
  "Entertainment": "bg-purple-500",
  "Bills & Utilities": "bg-yellow-500",
  "Healthcare": "bg-pink-500",
  "Other": "bg-gray-500",
};

export default function ExpenseTracker() {
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: expenses = [], isLoading } = useQuery<Expense[]>({
    queryKey: ["/api/expenses"],
  });

  const addExpenseMutation = useMutation({
    mutationFn: (expenseData: { amount: string; category: string; description: string; date: string }) =>
      apiRequest("POST", "/api/expenses", {
        ...expenseData,
        date: new Date(expenseData.date),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      setAmount("");
      setCategory("");
      setDescription("");
      setDate(new Date().toISOString().split('T')[0]);
      toast({ title: "Expense added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add expense", variant: "destructive" });
    },
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/expenses/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      toast({ title: "Expense deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete expense", variant: "destructive" });
    },
  });

  const handleAddExpense = () => {
    if (!amount || !category || !description || !date) return;
    addExpenseMutation.mutate({ amount, category, description, date });
  };

  const handleDeleteExpense = (id: string) => {
    deleteExpenseMutation.mutate(id);
  };

  // Calculate totals
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;

  const thisMonthExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
  });

  const lastMonthExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === lastMonth && expenseDate.getFullYear() === lastMonthYear;
  });

  const thisMonthTotal = thisMonthExpenses.reduce((sum, expense) => sum + parseFloat(expense.amount), 0);
  const lastMonthTotal = lastMonthExpenses.reduce((sum, expense) => sum + parseFloat(expense.amount), 0);

  // Calculate category breakdown
  const categoryTotals = categories.reduce((acc, cat) => {
    const total = thisMonthExpenses
      .filter(expense => expense.category === cat)
      .reduce((sum, expense) => sum + parseFloat(expense.amount), 0);
    return { ...acc, [cat]: total };
  }, {} as Record<string, number>);

  // Recent expenses (last 10)
  const recentExpenses = expenses.slice(0, 10);

  if (isLoading) {
    return (
      <div className="px-4 py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/2"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-20 bg-muted rounded"></div>
            <div className="h-20 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Expense Tracker</h2>
        <p className="text-muted-foreground">Track your spending by category</p>
      </div>

      {/* Expense Summary */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-destructive" data-testid="text-this-month-total">
                ₹{thisMonthTotal.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">This Month</div>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-muted-foreground" data-testid="text-last-month-total">
                ₹{lastMonthTotal.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">Last Month</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Expense Form */}
      <Card className="mb-6 shadow-sm">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-4">Add New Expense</h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="expense-amount">Amount (₹)</Label>
                <Input
                  id="expense-amount"
                  data-testid="input-expense-amount"
                  type="number"
                  placeholder="250"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger data-testid="select-expense-category" className="mt-2">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="expense-description">Description</Label>
              <Input
                id="expense-description"
                data-testid="input-expense-description"
                placeholder="Lunch at restaurant"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="expense-date">Date</Label>
              <Input
                id="expense-date"
                data-testid="input-expense-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-2"
              />
            </div>
            <Button
              data-testid="button-add-expense"
              onClick={handleAddExpense}
              className="w-full"
              disabled={!amount || !category || !description || !date || addExpenseMutation.isPending}
            >
              <Plus size={16} className="mr-2" />
              Add Expense
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Category Breakdown */}
      <Card className="mb-6 shadow-sm">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-4">Category Breakdown</h3>
          <div className="space-y-3">
            {categories.map((cat) => {
              const total = categoryTotals[cat];
              if (total === 0) return null;
              
              return (
                <div key={cat} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${categoryColors[cat]}`}></div>
                    <span className="text-sm">{cat}</span>
                  </div>
                  <span className="text-sm font-medium" data-testid={`text-category-${cat.toLowerCase().replace(/\s+/g, '-')}`}>
                    ₹{total.toLocaleString()}
                  </span>
                </div>
              );
            })}
            {Object.values(categoryTotals).every(total => total === 0) && (
              <p className="text-muted-foreground text-center py-4">
                No expenses this month
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Expenses */}
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Recent Expenses</h3>
          </div>
          <div className="space-y-3">
            {recentExpenses.length === 0 ? (
              <p className="text-muted-foreground text-center py-4" data-testid="text-no-expenses">
                No expenses recorded yet
              </p>
            ) : (
              recentExpenses.map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between py-2 border-b border-border last:border-b-0"
                >
                  <div>
                    <p className="font-medium text-sm" data-testid={`text-expense-description-${expense.id}`}>
                      {expense.description}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {expense.category} • {format(new Date(expense.date), "MMM dd, yyyy")}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">₹{parseFloat(expense.amount).toLocaleString()}</p>
                    <Button
                      data-testid={`button-delete-expense-${expense.id}`}
                      variant="ghost"
                      size="sm"
                      className="text-xs text-muted-foreground hover:text-destructive p-0 h-auto"
                      onClick={() => handleDeleteExpense(expense.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
