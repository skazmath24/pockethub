import { Calculator } from "lucide-react";

export default function MobileHeader() {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Calculator className="text-primary-foreground text-sm" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">Pockethub</h1>
            <p className="text-xs text-muted-foreground">Calculator & Tracker</p>
          </div>
        </div>
      </div>
    </header>
  );
}
