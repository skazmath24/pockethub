import { Calculator, CheckSquare, PieChart, CreditCard } from "lucide-react";
import type { TabType } from "@/pages/home";
import { cn } from "@/lib/utils";

interface BottomNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const navItems = [
    { id: "calculators" as const, icon: Calculator, label: "Calculators" },
    { id: "todo" as const, icon: CheckSquare, label: "Todo" },
    { id: "expenses" as const, icon: PieChart, label: "Expenses" },
    { id: "debts" as const, icon: CreditCard, label: "Debts" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
      <div className="flex">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              data-testid={`nav-${item.id}`}
              className={cn(
                "flex-1 flex flex-col items-center py-3 space-y-1 transition-colors",
                isActive && "nav-item active text-primary border-t-2 border-primary"
              )}
              onClick={() => onTabChange(item.id)}
            >
              <Icon className="text-lg" size={20} />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
