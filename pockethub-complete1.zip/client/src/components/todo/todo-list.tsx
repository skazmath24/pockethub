import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit2, Trash2, Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Todo } from "@shared/schema";
import { format } from "date-fns";

type FilterType = "all" | "pending" | "completed";

export default function TodoList() {
  const [newTodo, setNewTodo] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: todos = [], isLoading } = useQuery<Todo[]>({
    queryKey: ["/api/todos"],
  });

  const addTodoMutation = useMutation({
    mutationFn: (todoData: { title: string; completed: boolean }) =>
      apiRequest("POST", "/api/todos", todoData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      setNewTodo("");
      toast({ title: "Todo added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add todo", variant: "destructive" });
    },
  });

  const updateTodoMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<Todo> }) =>
      apiRequest("PATCH", `/api/todos/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      toast({ title: "Todo updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update todo", variant: "destructive" });
    },
  });

  const deleteTodoMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/todos/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      toast({ title: "Todo deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete todo", variant: "destructive" });
    },
  });

  const handleAddTodo = () => {
    if (!newTodo.trim()) return;
    addTodoMutation.mutate({ title: newTodo.trim(), completed: false });
  };

  const handleToggleComplete = (todo: Todo) => {
    updateTodoMutation.mutate({
      id: todo.id,
      updates: { completed: !todo.completed },
    });
  };

  const handleDeleteTodo = (id: string) => {
    deleteTodoMutation.mutate(id);
  };

  const filteredTodos = todos.filter((todo) => {
    if (filter === "pending") return !todo.completed;
    if (filter === "completed") return todo.completed;
    return true;
  });

  const pendingCount = todos.filter(todo => !todo.completed).length;
  const completedCount = todos.filter(todo => todo.completed).length;

  if (isLoading) {
    return (
      <div className="px-4 py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/2"></div>
          <div className="h-4 bg-muted rounded w-1/3"></div>
          <Card>
            <CardContent className="p-4">
              <div className="h-10 bg-muted rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">To-Do List</h2>
        <p className="text-muted-foreground">Manage your tasks efficiently</p>
      </div>

      {/* Add Todo Form */}
      <Card className="mb-6 shadow-sm">
        <CardContent className="p-4">
          <div className="flex space-x-3">
            <Input
              data-testid="input-new-todo"
              placeholder="Add a new task..."
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddTodo()}
              className="flex-1"
            />
            <Button
              data-testid="button-add-todo"
              onClick={handleAddTodo}
              disabled={!newTodo.trim() || addTodoMutation.isPending}
            >
              <Plus size={16} className="mr-2" />
              Add
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filter Tabs */}
      <div className="flex space-x-2 mb-4 overflow-x-auto">
        <Button
          data-testid="filter-all"
          variant={filter === "all" ? "default" : "outline"}
          size="sm"
          className="whitespace-nowrap"
          onClick={() => setFilter("all")}
        >
          All ({todos.length})
        </Button>
        <Button
          data-testid="filter-pending"
          variant={filter === "pending" ? "default" : "outline"}
          size="sm"
          className="whitespace-nowrap"
          onClick={() => setFilter("pending")}
        >
          Pending ({pendingCount})
        </Button>
        <Button
          data-testid="filter-completed"
          variant={filter === "completed" ? "default" : "outline"}
          size="sm"
          className="whitespace-nowrap"
          onClick={() => setFilter("completed")}
        >
          Completed ({completedCount})
        </Button>
      </div>

      {/* Todo Items */}
      <div className="space-y-3">
        {filteredTodos.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground" data-testid="text-no-todos">
                {filter === "all" ? "No todos yet. Add your first task!" : 
                 filter === "pending" ? "No pending tasks!" : 
                 "No completed tasks yet."}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredTodos.map((todo) => (
            <Card key={todo.id} className="shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <Checkbox
                    data-testid={`checkbox-todo-${todo.id}`}
                    checked={todo.completed || false}
                    onCheckedChange={() => handleToggleComplete(todo)}
                  />
                  <div className="flex-1">
                    <p
                      className={`font-medium ${
                        todo.completed
                          ? "line-through text-muted-foreground"
                          : ""
                      }`}
                      data-testid={`text-todo-title-${todo.id}`}
                    >
                      {todo.title}
                    </p>
                    {todo.createdAt && (
                      <p className="text-sm text-muted-foreground">
                        Created: {format(new Date(todo.createdAt), "MMM dd, yyyy")}
                      </p>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      data-testid={`button-delete-todo-${todo.id}`}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteTodo(todo.id)}
                      disabled={deleteTodoMutation.isPending}
                    >
                      <Trash2 size={16} className="text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
