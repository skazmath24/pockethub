import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, Check, Edit2, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Debt } from "@shared/schema";
import { format } from "date-fns";

type FilterType = "all" | "lent" | "borrowed";

export default function DebtTracker() {
  const [debtType, setDebtType] = useState<"lent" | "borrowed">("lent");
  const [personName, setPersonName] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: debts = [], isLoading } = useQuery<Debt[]>({
    queryKey: ["/api/debts"],
  });

  const addDebtMutation = useMutation({
    mutationFn: (debtData: { personName: string; amount: string; type: string; description: string; date: string; settled: boolean }) =>
      apiRequest("POST", "/api/debts", {
        ...debtData,
        date: new Date(debtData.date),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/debts"] });
      setPersonName("");
      setAmount("");
      setDescription("");
      setDate(new Date().toISOString().split('T')[0]);
      toast({ title: "Debt record added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add debt record", variant: "destructive" });
    },
  });

  const updateDebtMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<Debt> }) =>
      apiRequest("PATCH", `/api/debts/${id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/debts"] });
      toast({ title: "Debt updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update debt", variant: "destructive" });
    },
  });

  const deleteDebtMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/debts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/debts"] });
      toast({ title: "Debt record deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete debt record", variant: "destructive" });
    },
  });

  const handleAddDebt = () => {
    if (!personName || !amount || !date) return;
    addDebtMutation.mutate({
      personName,
      amount,
      type: debtType,
      description,
      date,
      settled: false,
    });
  };

  const handleMarkSettled = (debt: Debt) => {
    updateDebtMutation.mutate({
      id: debt.id,
      updates: { settled: true, settledDate: new Date() },
    });
  };

  const handleDeleteDebt = (id: string) => {
    deleteDebtMutation.mutate(id);
  };

  // Calculate totals
  const activeDebts = debts.filter(debt => !debt.settled);
  const lentTotal = activeDebts
    .filter(debt => debt.type === "lent")
    .reduce((sum, debt) => sum + parseFloat(debt.amount), 0);
  const borrowedTotal = activeDebts
    .filter(debt => debt.type === "borrowed")
    .reduce((sum, debt) => sum + parseFloat(debt.amount), 0);

  // Filter debts
  const filteredDebts = debts.filter((debt) => {
    if (filter === "lent") return debt.type === "lent";
    if (filter === "borrowed") return debt.type === "borrowed";
    return true;
  });

  if (isLoading) {
    return (
      <div className="px-4 py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/2"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-20 bg-muted rounded"></div>
            <div className="h-20 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Debt Records</h2>
        <p className="text-muted-foreground">Track money borrowed and lent</p>
      </div>

      {/* Debt Summary */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600" data-testid="text-lent-total">
                ₹{lentTotal.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">You'll Receive</div>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600" data-testid="text-borrowed-total">
                ₹{borrowedTotal.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">You Owe</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Debt Form */}
      <Card className="mb-6 shadow-sm">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-4">Add New Record</h3>
          <div className="space-y-4">
            <div className="flex space-x-2">
              <Button
                data-testid="button-set-lent"
                variant={debtType === "lent" ? "default" : "outline"}
                className="flex-1 bg-green-50 border-green-200 text-green-700 hover:bg-green-100"
                onClick={() => setDebtType("lent")}
              >
                I Lent
              </Button>
              <Button
                data-testid="button-set-borrowed"
                variant={debtType === "borrowed" ? "default" : "outline"}
                className="flex-1"
                onClick={() => setDebtType("borrowed")}
              >
                I Borrowed
              </Button>
            </div>
            <div>
              <Label htmlFor="debt-person">Person's Name</Label>
              <Input
                id="debt-person"
                data-testid="input-debt-person"
                placeholder="Enter name"
                value={personName}
                onChange={(e) => setPersonName(e.target.value)}
                className="mt-2"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="debt-amount">Amount (₹)</Label>
                <Input
                  id="debt-amount"
                  data-testid="input-debt-amount"
                  type="number"
                  placeholder="5000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="debt-date">Date</Label>
                <Input
                  id="debt-date"
                  data-testid="input-debt-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="mt-2"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="debt-description">Description (Optional)</Label>
              <Input
                id="debt-description"
                data-testid="input-debt-description"
                placeholder="What was it for?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-2"
              />
            </div>
            <Button
              data-testid="button-add-debt"
              onClick={handleAddDebt}
              className="w-full"
              disabled={!personName || !amount || !date || addDebtMutation.isPending}
            >
              Add Record
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filter Tabs */}
      <div className="flex space-x-2 mb-4">
        <Button
          data-testid="filter-all-debts"
          variant={filter === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("all")}
        >
          All
        </Button>
        <Button
          data-testid="filter-lent-debts"
          variant={filter === "lent" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("lent")}
        >
          I Lent
        </Button>
        <Button
          data-testid="filter-borrowed-debts"
          variant={filter === "borrowed" ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter("borrowed")}
        >
          I Borrowed
        </Button>
      </div>

      {/* Debt Records */}
      <div className="space-y-3">
        {filteredDebts.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground" data-testid="text-no-debts">
                No debt records found
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredDebts.map((debt) => (
            <Card key={debt.id} className={`shadow-sm ${debt.settled ? "opacity-60" : ""}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      debt.settled ? "bg-gray-100" : 
                      debt.type === "lent" ? "bg-green-100" : "bg-red-100"
                    }`}>
                      {debt.settled ? (
                        <Check className="text-gray-600" size={20} />
                      ) : debt.type === "lent" ? (
                        <ArrowDown className="text-green-600" size={20} />
                      ) : (
                        <ArrowUp className="text-red-600" size={20} />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold" data-testid={`text-debt-person-${debt.id}`}>
                        {debt.personName}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {debt.settled 
                          ? `Settled • ${format(new Date(debt.settledDate!), "MMM dd, yyyy")}`
                          : format(new Date(debt.date), "MMM dd, yyyy")
                        }
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg font-bold ${
                      debt.settled ? "text-gray-600 line-through" : 
                      debt.type === "lent" ? "text-green-600" : "text-red-600"
                    }`} data-testid={`text-debt-amount-${debt.id}`}>
                      ₹{parseFloat(debt.amount).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {debt.settled ? "Settled" : debt.type === "lent" ? "You lent" : "You owe"}
                    </p>
                  </div>
                </div>
                {debt.description && (
                  <p className="text-sm text-muted-foreground mb-3">
                    {debt.description}
                  </p>
                )}
                {!debt.settled && (
                  <div className="flex space-x-2">
                    <Button
                      data-testid={`button-settle-debt-${debt.id}`}
                      variant="outline"
                      size="sm"
                      className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                      onClick={() => handleMarkSettled(debt)}
                      disabled={updateDebtMutation.isPending}
                    >
                      Mark as Settled
                    </Button>
                    <Button
                      data-testid={`button-delete-debt-${debt.id}`}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteDebt(debt.id)}
                      disabled={deleteDebtMutation.isPending}
                    >
                      <Trash2 size={16} className="text-destructive" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
