import { useState } from "react";
import { TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface SIPResult {
  totalInvestment: number;
  totalReturns: number;
  maturityValue: number;
}

export default function SIPCalculator() {
  const [monthlyAmount, setMonthlyAmount] = useState("");
  const [expectedReturn, setExpectedReturn] = useState("");
  const [timePeriod, setTimePeriod] = useState("");
  const [result, setResult] = useState<SIPResult | null>(null);

  const calculateSIP = () => {
    const monthlyInvestment = parseFloat(monthlyAmount);
    const annualReturn = parseFloat(expectedReturn);
    const years = parseFloat(timePeriod);
    
    if (!monthlyInvestment || !annualReturn || !years) return;

    const monthlyReturn = annualReturn / 100 / 12;
    const totalMonths = years * 12;
    
    // SIP maturity calculation using compound interest formula
    const maturityValue = monthlyInvestment * (((Math.pow(1 + monthlyReturn, totalMonths) - 1) / monthlyReturn) * (1 + monthlyReturn));
    const totalInvestment = monthlyInvestment * totalMonths;
    const totalReturns = maturityValue - totalInvestment;

    setResult({
      totalInvestment: Math.round(totalInvestment),
      totalReturns: Math.round(totalReturns),
      maturityValue: Math.round(maturityValue),
    });
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900 rounded-lg flex items-center justify-center">
            <TrendingUp className="text-indigo-600 dark:text-indigo-400" size={20} />
          </div>
          <div>
            <h3 className="font-semibold">SIP Calculator</h3>
            <p className="text-sm text-muted-foreground">Investment planning tool</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="sip-amount">Monthly Investment (₹)</Label>
            <Input
              id="sip-amount"
              data-testid="input-sip-amount"
              type="number"
              placeholder="5000"
              value={monthlyAmount}
              onChange={(e) => setMonthlyAmount(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="sip-return">Expected Return (%)</Label>
              <Input
                id="sip-return"
                data-testid="input-sip-return"
                type="number"
                placeholder="12"
                step="0.1"
                value={expectedReturn}
                onChange={(e) => setExpectedReturn(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="sip-period">Time Period (Years)</Label>
              <Input
                id="sip-period"
                data-testid="input-sip-period"
                type="number"
                placeholder="10"
                value={timePeriod}
                onChange={(e) => setTimePeriod(e.target.value)}
                className="mt-2"
              />
            </div>
          </div>
          
          <Button 
            data-testid="button-calculate-sip"
            onClick={calculateSIP} 
            className="w-full"
            disabled={!monthlyAmount || !expectedReturn || !timePeriod}
          >
            Calculate SIP
          </Button>
          
          {result && (
            <div className="bg-muted rounded-lg p-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Total Investment</span>
                  <span className="font-semibold" data-testid="text-total-investment">
                    ₹{result.totalInvestment.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Total Returns</span>
                  <span className="text-sm text-accent">
                    ₹{result.totalReturns.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between border-t border-border pt-2">
                  <span className="text-sm font-medium">Maturity Value</span>
                  <span className="font-bold text-accent" data-testid="text-maturity-value">
                    ₹{result.maturityValue.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
