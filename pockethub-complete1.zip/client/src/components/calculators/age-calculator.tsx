import { useState } from "react";
import { Calendar } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AgeResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalHours: number;
  totalMinutes: number;
}

export default function AgeCalculator() {
  const [birthDate, setBirthDate] = useState("");
  const [calculateDate, setCalculateDate] = useState(new Date().toISOString().split('T')[0]);
  const [result, setResult] = useState<AgeResult | null>(null);

  const calculateAge = () => {
    if (!birthDate || !calculateDate) return;

    const birth = new Date(birthDate);
    const target = new Date(calculateDate);
    
    if (birth > target) return;

    let years = target.getFullYear() - birth.getFullYear();
    let months = target.getMonth() - birth.getMonth();
    let days = target.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      const lastMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += lastMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDays = Math.floor((target.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;

    setResult({
      years,
      months,
      days,
      totalDays,
      totalHours,
      totalMinutes,
    });
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
            <Calendar className="text-blue-600 dark:text-blue-400" size={20} />
          </div>
          <div>
            <h3 className="font-semibold">Age Calculator</h3>
            <p className="text-sm text-muted-foreground">Calculate precise age</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="birth-date">Birth Date</Label>
            <Input
              id="birth-date"
              data-testid="input-birth-date"
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <div>
            <Label htmlFor="calculate-date">Calculate Until</Label>
            <Input
              id="calculate-date"
              data-testid="input-calculate-date"
              type="date"
              value={calculateDate}
              onChange={(e) => setCalculateDate(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <Button 
            data-testid="button-calculate-age"
            onClick={calculateAge} 
            className="w-full"
            disabled={!birthDate || !calculateDate}
          >
            Calculate Age
          </Button>
          
          {result && (
            <div className="bg-muted rounded-lg p-4">
              <div className="text-center">
                <div className="text-2xl font-bold" data-testid="text-age-result">
                  {result.years} Years
                </div>
                <div className="text-sm text-muted-foreground">
                  {result.months} months, {result.days} days
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {result.totalDays.toLocaleString()} days • {result.totalHours.toLocaleString()} hours
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
