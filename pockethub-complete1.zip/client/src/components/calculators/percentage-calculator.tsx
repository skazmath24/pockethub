import { useState } from "react";
import { Percent } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function PercentageCalculator() {
  const [calculationType, setCalculationType] = useState("what-is");
  const [firstValue, setFirstValue] = useState("");
  const [secondValue, setSecondValue] = useState("");
  const [result, setResult] = useState<{ value: number; explanation: string } | null>(null);

  const calculatePercentage = () => {
    const val1 = parseFloat(firstValue);
    const val2 = parseFloat(secondValue);
    
    if (!val1 || !val2) return;

    let calculatedResult = 0;
    let explanation = "";

    switch (calculationType) {
      case "what-is":
        calculatedResult = (val1 / 100) * val2;
        explanation = `${val1}% of ${val2} is ${calculatedResult}`;
        break;
      case "is-what-percent":
        calculatedResult = (val1 / val2) * 100;
        explanation = `${val1} is ${calculatedResult.toFixed(2)}% of ${val2}`;
        break;
      case "is-percent-of-what":
        calculatedResult = val1 / (val2 / 100);
        explanation = `${val1} is ${val2}% of ${calculatedResult}`;
        break;
      case "percentage-change":
        calculatedResult = ((val2 - val1) / val1) * 100;
        explanation = `${val1} to ${val2} is ${calculatedResult > 0 ? '+' : ''}${calculatedResult.toFixed(2)}% change`;
        break;
    }

    setResult({ value: calculatedResult, explanation });
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center">
            <Percent className="text-purple-600 dark:text-purple-400" size={20} />
          </div>
          <div>
            <h3 className="font-semibold">Percentage Calculator</h3>
            <p className="text-sm text-muted-foreground">Various percentage operations</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label>Calculation Type</Label>
            <Select value={calculationType} onValueChange={setCalculationType}>
              <SelectTrigger data-testid="select-percentage-type" className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="what-is">What is X% of Y?</SelectItem>
                <SelectItem value="is-what-percent">X is what % of Y?</SelectItem>
                <SelectItem value="is-percent-of-what">X is Y% of what?</SelectItem>
                <SelectItem value="percentage-change">Percentage change</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="first-value">First Value</Label>
              <Input
                id="first-value"
                data-testid="input-first-value"
                type="number"
                placeholder="25"
                value={firstValue}
                onChange={(e) => setFirstValue(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="second-value">Second Value</Label>
              <Input
                id="second-value"
                data-testid="input-second-value"
                type="number"
                placeholder="200"
                value={secondValue}
                onChange={(e) => setSecondValue(e.target.value)}
                className="mt-2"
              />
            </div>
          </div>
          
          <Button 
            data-testid="button-calculate-percentage"
            onClick={calculatePercentage} 
            className="w-full"
            disabled={!firstValue || !secondValue}
          >
            Calculate
          </Button>
          
          {result && (
            <div className="bg-muted rounded-lg p-4 text-center">
              <div className="text-2xl font-bold" data-testid="text-percentage-result">
                {typeof result.value === 'number' ? result.value.toFixed(2) : result.value}
              </div>
              <div className="text-sm text-muted-foreground">
                {result.explanation}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
