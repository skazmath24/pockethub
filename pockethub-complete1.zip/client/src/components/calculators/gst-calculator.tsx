import { useState } from "react";
import { Receipt } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface GSTResult {
  originalAmount: number;
  gstAmount: number;
  totalAmount: number;
  gstRate: number;
}

export default function GSTCalculator() {
  const [isExclusive, setIsExclusive] = useState(true);
  const [amount, setAmount] = useState("");
  const [gstRate, setGstRate] = useState("18");
  const [result, setResult] = useState<GSTResult | null>(null);

  const calculateGST = () => {
    const inputAmount = parseFloat(amount);
    const rate = parseFloat(gstRate);
    
    if (!inputAmount || !rate) return;

    let originalAmount: number;
    let gstAmount: number;
    let totalAmount: number;

    if (isExclusive) {
      // GST Exclusive - add GST to the amount
      originalAmount = inputAmount;
      gstAmount = (inputAmount * rate) / 100;
      totalAmount = inputAmount + gstAmount;
    } else {
      // GST Inclusive - extract GST from the amount
      totalAmount = inputAmount;
      originalAmount = inputAmount / (1 + rate / 100);
      gstAmount = inputAmount - originalAmount;
    }

    setResult({
      originalAmount: Math.round(originalAmount * 100) / 100,
      gstAmount: Math.round(gstAmount * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100,
      gstRate: rate,
    });
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center">
            <Receipt className="text-orange-600 dark:text-orange-400" size={20} />
          </div>
          <div>
            <h3 className="font-semibold">GST Calculator</h3>
            <p className="text-sm text-muted-foreground">Tax calculation tool</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex space-x-2">
            <Button
              data-testid="button-exclusive"
              variant={isExclusive ? "default" : "outline"}
              className="flex-1"
              onClick={() => setIsExclusive(true)}
            >
              Exclusive
            </Button>
            <Button
              data-testid="button-inclusive"
              variant={!isExclusive ? "default" : "outline"}
              className="flex-1"
              onClick={() => setIsExclusive(false)}
            >
              Inclusive
            </Button>
          </div>
          
          <div>
            <Label htmlFor="gst-amount">Amount (₹)</Label>
            <Input
              id="gst-amount"
              data-testid="input-gst-amount"
              type="number"
              placeholder="10000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <div>
            <Label>GST Rate (%)</Label>
            <Select value={gstRate} onValueChange={setGstRate}>
              <SelectTrigger data-testid="select-gst-rate" className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5%</SelectItem>
                <SelectItem value="12">12%</SelectItem>
                <SelectItem value="18">18%</SelectItem>
                <SelectItem value="28">28%</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            data-testid="button-calculate-gst"
            onClick={calculateGST} 
            className="w-full"
            disabled={!amount || !gstRate}
          >
            Calculate GST
          </Button>
          
          {result && (
            <div className="bg-muted rounded-lg p-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Original Amount</span>
                  <span className="font-semibold" data-testid="text-original-amount">
                    ₹{result.originalAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">GST ({result.gstRate}%)</span>
                  <span className="text-sm text-muted-foreground">
                    ₹{result.gstAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between border-t border-border pt-2">
                  <span className="text-sm font-medium">Total Amount</span>
                  <span className="font-semibold">
                    ₹{result.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
