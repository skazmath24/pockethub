import { useState } from "react";
import { Home, ChevronDown, ChevronUp, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface EMIResult {
  emi: number;
  totalInterest: number;
  totalAmount: number;
}

interface AmortizationEntry {
  month: number;
  emiAmount: number;
  principalAmount: number;
  interestAmount: number;
  outstandingBalance: number;
}

interface CumulativeTotals {
  totalPrincipalPaid: number;
  totalInterestPaid: number;
  totalAmountPaid: number;
}

export default function EMICalculator() {
  const [loanAmount, setLoanAmount] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [tenure, setTenure] = useState("");
  const [result, setResult] = useState<EMIResult | null>(null);
  const [amortizationSchedule, setAmortizationSchedule] = useState<AmortizationEntry[]>([]);
  const [showAmortization, setShowAmortization] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number | null>(null);
  const [showPopup, setShowPopup] = useState(false);

  const calculateEMI = () => {
    const principal = parseFloat(loanAmount);
    const rate = parseFloat(interestRate) / 100 / 12;
    const months = parseFloat(tenure) * 12;

    if (!principal || !rate || !months) return;

    const emi = (principal * rate * Math.pow(1 + rate, months)) / (Math.pow(1 + rate, months) - 1);
    const totalAmount = emi * months;
    const totalInterest = totalAmount - principal;

    setResult({
      emi: Math.round(emi),
      totalInterest: Math.round(totalInterest),
      totalAmount: Math.round(totalAmount),
    });

    // Generate amortization schedule
    const schedule: AmortizationEntry[] = [];
    let outstandingBalance = principal;
    
    for (let month = 1; month <= months; month++) {
      const interestAmount = outstandingBalance * rate;
      const principalAmount = emi - interestAmount;
      outstandingBalance = outstandingBalance - principalAmount;
      
      schedule.push({
        month,
        emiAmount: Math.round(emi),
        principalAmount: Math.round(principalAmount),
        interestAmount: Math.round(interestAmount),
        outstandingBalance: Math.round(Math.max(0, outstandingBalance)),
      });
    }
    
    setAmortizationSchedule(schedule);
  };

  const calculateCumulativeTotals = (upToMonth: number): CumulativeTotals => {
    const monthsData = amortizationSchedule.slice(0, upToMonth);
    const totalPrincipalPaid = monthsData.reduce((sum, entry) => sum + entry.principalAmount, 0);
    const totalInterestPaid = monthsData.reduce((sum, entry) => sum + entry.interestAmount, 0);
    const totalAmountPaid = totalPrincipalPaid + totalInterestPaid;
    
    return {
      totalPrincipalPaid,
      totalInterestPaid,
      totalAmountPaid,
    };
  };

  const handleRowClick = (month: number) => {
    setSelectedMonth(month);
    setShowPopup(true);
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center">
            <Home className="text-green-600 dark:text-green-400" size={20} />
          </div>
          <div>
            <h3 className="font-semibold">EMI Calculator</h3>
            <p className="text-sm text-muted-foreground">Loan EMI calculation</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="loan-amount">Loan Amount (₹)</Label>
            <Input
              id="loan-amount"
              data-testid="input-loan-amount"
              type="number"
              placeholder="500000"
              value={loanAmount}
              onChange={(e) => setLoanAmount(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="interest-rate">Interest Rate (%)</Label>
              <Input
                id="interest-rate"
                data-testid="input-interest-rate"
                type="number"
                placeholder="8.5"
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="loan-tenure">Tenure (Years)</Label>
              <Input
                id="loan-tenure"
                data-testid="input-loan-tenure"
                type="number"
                placeholder="20"
                value={tenure}
                onChange={(e) => setTenure(e.target.value)}
                className="mt-2"
              />
            </div>
          </div>
          
          <Button 
            data-testid="button-calculate-emi"
            onClick={calculateEMI} 
            className="w-full"
            disabled={!loanAmount || !interestRate || !tenure}
          >
            Calculate EMI
          </Button>
          
          {result && (
            <>
              <div className="bg-muted rounded-lg p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Monthly EMI</span>
                    <span className="font-semibold" data-testid="text-emi-amount">
                      ₹{result.emi.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Total Interest</span>
                    <span className="text-sm text-muted-foreground">
                      ₹{result.totalInterest.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Total Amount</span>
                    <span className="text-sm text-muted-foreground">
                      ₹{result.totalAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Amortization Chart Toggle */}
              <Button
                data-testid="button-toggle-amortization"
                variant="outline"
                className="w-full mt-2"
                onClick={() => setShowAmortization(!showAmortization)}
              >
                {showAmortization ? (
                  <>
                    <ChevronUp size={16} className="mr-2" />
                    Hide Amortization Schedule
                  </>
                ) : (
                  <>
                    <ChevronDown size={16} className="mr-2" />
                    View Amortization Schedule
                  </>
                )}
              </Button>
              
              {/* Amortization Schedule */}
              {showAmortization && (
                <div className="bg-muted rounded-lg p-4 mt-4">
                  <h4 className="font-semibold mb-3">Amortization Schedule</h4>
                  <div className="max-h-80 overflow-y-auto">
                    <div className="grid grid-cols-5 gap-2 text-xs font-semibold mb-2 sticky top-0 bg-muted py-2 z-10">
                      <span>Month</span>
                      <span>EMI</span>
                      <span>Principal</span>
                      <span>Interest</span>
                      <span>Balance</span>
                    </div>
                    {amortizationSchedule.map((entry) => (
                      <div 
                        key={entry.month} 
                        className="grid grid-cols-5 gap-2 text-xs py-2 border-b border-border/50 hover:bg-background/50 cursor-pointer transition-colors"
                        onClick={() => handleRowClick(entry.month)}
                        data-testid={`amortization-row-${entry.month}`}
                      >
                        <span data-testid={`amortization-month-${entry.month}`} className="font-medium">{entry.month}</span>
                        <span className="font-medium">₹{entry.emiAmount.toLocaleString()}</span>
                        <span className="text-green-600 font-medium">₹{entry.principalAmount.toLocaleString()}</span>
                        <span className="text-red-600 font-medium">₹{entry.interestAmount.toLocaleString()}</span>
                        <span>₹{entry.outstandingBalance.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 text-xs text-muted-foreground">
                    <div className="flex justify-between items-center">
                      <span>Click on any month to view cumulative totals</span>
                      <div className="flex space-x-4">
                        <span><span className="inline-block w-2 h-2 bg-green-600 rounded mr-1"></span>Principal</span>
                        <span><span className="inline-block w-2 h-2 bg-red-600 rounded mr-1"></span>Interest</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </CardContent>

      {/* Popup Dialog for Cumulative Totals */}
      <Dialog open={showPopup} onOpenChange={setShowPopup}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Info size={20} className="text-primary" />
              <span>Cumulative Totals - Month {selectedMonth}</span>
            </DialogTitle>
          </DialogHeader>
          {selectedMonth && (
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4">
                <h4 className="font-semibold mb-3">Payments made up to Month {selectedMonth}</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total Amount Paid</span>
                    <span className="font-bold text-lg" data-testid="popup-total-amount">
                      ₹{calculateCumulativeTotals(selectedMonth).totalAmountPaid.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-green-600">Total Principal Paid</span>
                    <span className="font-semibold text-green-600" data-testid="popup-total-principal">
                      ₹{calculateCumulativeTotals(selectedMonth).totalPrincipalPaid.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-red-600">Total Interest Paid</span>
                    <span className="font-semibold text-red-600" data-testid="popup-total-interest">
                      ₹{calculateCumulativeTotals(selectedMonth).totalInterestPaid.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="text-xs text-muted-foreground bg-accent/20 p-3 rounded">
                <p className="mb-1">
                  <strong>Remaining Balance:</strong> ₹{amortizationSchedule[selectedMonth - 1]?.outstandingBalance.toLocaleString()}
                </p>
                <p>
                  <strong>Months Remaining:</strong> {amortizationSchedule.length - selectedMonth} months
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
