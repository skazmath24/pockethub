# Multi-Tool Application - Deployment Guide

A comprehensive web application with financial calculators and personal management tools, ready for self-hosting.

## Features

### Financial Calculators
- **Age Calculator** - Calculate precise age with years, months, days
- **EMI Calculator** - Loan EMI calculations with interest breakdown
- **Percentage Calculator** - Various percentage operations
- **GST Calculator** - Tax calculations (inclusive/exclusive)
- **SIP Calculator** - Investment planning tool

### Personal Management Tools
- **Todo List** - Task management with filtering
- **Expense Tracker** - Track spending by category with monthly summaries
- **Debt Tracker** - Track money lent/borrowed with settlement status

## Deployment Options

### Option 1: Docker Deployment (Recommended)

#### Prerequisites
- Docker and Docker Compose installed
- Domain name (optional)

#### Quick Start
```bash
# Clone or extract your application files
# Navigate to the application directory

# Copy and configure environment
cp .env.example .env
# Edit .env with your database credentials

# Start with Docker Compose
docker-compose up -d

# Your app will be available at http://localhost:5000
```

#### Configuration
Edit `docker-compose.yml` to customize:
- Database credentials
- Port mappings
- Volume mounts
- Environment variables

### Option 2: Traditional Server Deployment

#### Prerequisites
- Node.js 20+ installed
- PostgreSQL database
- PM2 (for production management)

#### Step-by-Step Deployment

1. **Prepare the Server**
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib
```

2. **Setup Database**
```bash
# Create database and user
sudo -u postgres psql
CREATE DATABASE multitool;
CREATE USER multitool_user WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE multitool TO multitool_user;
\q

# Import schema
psql -U multitool_user -d multitool -f init.sql
```

3. **Deploy Application**
```bash
# Make deployment script executable
chmod +x deploy.sh

# Run deployment
./deploy.sh
```

4. **Setup Nginx (Optional)**
```nginx
# /etc/nginx/sites-available/multitool
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site and restart Nginx
sudo ln -s /etc/nginx/sites-available/multitool /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Option 3: Cloud Platform Deployment

#### Railway
1. Connect your GitHub repository to Railway
2. Add PostgreSQL service
3. Set environment variables
4. Deploy automatically

#### DigitalOcean App Platform
1. Create new app from GitHub repository
2. Add managed PostgreSQL database
3. Configure environment variables
4. Deploy

#### Heroku
1. Create new Heroku app
2. Add Heroku Postgres addon
3. Set config vars
4. Deploy via Git

## Environment Configuration

### Required Environment Variables
```env
NODE_ENV=production
DATABASE_URL=postgresql://username:password@host:port/database
PORT=5000
SESSION_SECRET=your-super-secret-key
```

### Database URL Examples
```env
# Local PostgreSQL
DATABASE_URL=postgresql://multitool_user:password@localhost:5432/multitool

# Neon Database (Serverless)
DATABASE_URL=postgresql://username:password@endpoint.neon.tech/database

# Railway PostgreSQL
DATABASE_URL=postgresql://username:password@containers-us-west-xxx.railway.app:port/railway

# DigitalOcean Managed Database
DATABASE_URL=postgresql://username:password@host-region.db.ondigitalocean.com:port/database?sslmode=require
```

## Production Management

### Using PM2
```bash
# Start application
pm2 start ecosystem.config.js --env production

# Monitor application
pm2 monit

# View logs
pm2 logs multitool-app

# Restart application
pm2 restart multitool-app

# Stop application
pm2 stop multitool-app

# Save PM2 configuration
pm2 save
pm2 startup
```

### Using Docker
```bash
# View running containers
docker-compose ps

# View logs
docker-compose logs -f

# Restart services
docker-compose restart

# Update application
docker-compose down
docker-compose build
docker-compose up -d

# Backup database
docker-compose exec db pg_dump -U postgres multitool > backup.sql
```

## Security Considerations

1. **Database Security**
   - Use strong passwords
   - Enable SSL/TLS connections
   - Restrict database access to application only

2. **Application Security**
   - Set strong SESSION_SECRET
   - Use HTTPS in production
   - Keep dependencies updated

3. **Server Security**
   - Configure firewall
   - Use fail2ban for SSH protection
   - Regular security updates

## Monitoring and Maintenance

### Log Files
- Application logs: `./logs/`
- PM2 logs: `~/.pm2/logs/`
- Nginx logs: `/var/log/nginx/`

### Health Checks
- Application health: `curl http://localhost:5000/health`
- Database connection: Check application logs

### Backup Strategy
1. Database backups (daily)
2. Application code backups
3. Configuration file backups

## Troubleshooting

### Common Issues

1. **Port 5000 already in use**
   ```bash
   # Check what's using port 5000
   sudo lsof -i :5000
   # Kill the process or change PORT in .env
   ```

2. **Database connection errors**
   - Verify DATABASE_URL format
   - Check database server status
   - Confirm network connectivity

3. **Build failures**
   - Check Node.js version (requires 20+)
   - Clear node_modules and reinstall
   - Check available disk space

## Support

For deployment issues:
1. Check logs for error messages
2. Verify environment configuration
3. Test database connectivity
4. Ensure all dependencies are installed

## License
MIT License - feel free to use for personal and commercial projects.