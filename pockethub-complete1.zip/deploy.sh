#!/bin/bash

# Multi-Tool Application Deployment Script
# This script helps deploy the application to your own server

set -e

echo "🚀 Starting Multi-Tool Application Deployment..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Copying from .env.example..."
    cp .env.example .env
    echo "📝 Please edit .env file with your database credentials and run this script again."
    exit 1
fi

# Load environment variables
source .env

echo "🔧 Installing dependencies..."
npm ci --only=production

echo "🏗️  Building application..."
npm run build

echo "📂 Creating necessary directories..."
mkdir -p logs

# Check if PM2 is installed globally
if ! command -v pm2 &> /dev/null; then
    echo "📦 Installing PM2 globally..."
    npm install -g pm2
fi

echo "🔄 Starting application with PM2..."
pm2 delete multitool-app 2>/dev/null || true
pm2 start ecosystem.config.js --env production

echo "💾 Saving PM2 configuration..."
pm2 save
pm2 startup

echo "✅ Deployment completed successfully!"
echo "🌐 Your Multi-Tool application is now running on http://localhost:5000"
echo "📊 Monitor with: pm2 monit"
echo "📋 Check logs with: pm2 logs multitool-app"
echo "🔄 Restart with: pm2 restart multitool-app"
echo "🛑 Stop with: pm2 stop multitool-app"