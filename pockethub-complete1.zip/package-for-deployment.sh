#!/bin/bash

echo "📦 Creating Pockethub deployment package..."

# Create deployment directory
mkdir -p pockethub-deployment

# Copy all necessary files
cp -r client pockethub-deployment/
cp -r server pockethub-deployment/
cp -r shared pockethub-deployment/
cp package*.json pockethub-deployment/
cp tsconfig.json pockethub-deployment/
cp vite.config.ts pockethub-deployment/
cp tailwind.config.ts pockethub-deployment/
cp postcss.config.js pockethub-deployment/
cp components.json pockethub-deployment/
cp drizzle.config.ts pockethub-deployment/

# Copy deployment files
cp Dockerfile pockethub-deployment/
cp .dockerignore pockethub-deployment/
cp docker-compose.yml pockethub-deployment/
cp .env.example pockethub-deployment/
cp init.sql pockethub-deployment/
cp ecosystem.config.js pockethub-deployment/
cp deploy.sh pockethub-deployment/
cp README-DEPLOYMENT.md pockethub-deployment/
cp INSTALLATION-GUIDE.md pockethub-deployment/

# Make scripts executable
chmod +x pockethub-deployment/deploy.sh

# Create archive
tar -czf pockethub-complete.tar.gz pockethub-deployment/

# Clean up temporary directory
rm -rf pockethub-deployment

echo "✅ Package created: pockethub-complete.tar.gz"
echo "📋 Package contents:"
echo "   - Complete source code"
echo "   - Docker configuration"
echo "   - Database schema"
echo "   - Deployment scripts"
echo "   - Installation guide"
echo ""
echo "🚀 To deploy on your server:"
echo "1. Extract: tar -xzf pockethub-complete.tar.gz"
echo "2. Configure: cd pockethub-deployment && cp .env.example .env"
echo "3. Deploy: ./deploy.sh"