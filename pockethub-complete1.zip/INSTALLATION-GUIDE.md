# Pockethub Installation Guide

Complete guide to install Pockethub Calculator & Tracker on your own hosting server.

## What You'll Get

Pockethub is a comprehensive web application with:
- **5 Financial Calculators**: Age, EMI, Percentage, GST, SIP
- **3 Management Tools**: Todo List, Expense Tracker, Debt Records
- **Mobile-First Design**: Works perfectly on all devices
- **Real-time Updates**: Instant data synchronization
- **Production Ready**: Optimized for performance and security

## Server Requirements

### Minimum Requirements
- **CPU**: 1 core (2+ cores recommended)
- **RAM**: 512MB (1GB+ recommended)
- **Storage**: 1GB free space
- **OS**: Ubuntu 20.04+, CentOS 7+, or any Linux distribution
- **Network**: Public IP address or domain name

### Software Requirements
- **Node.js**: Version 20 or higher
- **PostgreSQL**: Version 12 or higher
- **Nginx**: For reverse proxy (optional but recommended)
- **PM2**: For process management (will be installed automatically)

## Installation Methods

### Method 1: Docker Installation (Easiest)

**Step 1: Install Docker**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Add current user to docker group
sudo usermod -aG docker $USER
newgrp docker
```

**Step 2: Deploy Pockethub**
```bash
# Extract the zip file
unzip pockethub-complete.zip
cd pockethub-complete

# Configure environment
cp .env.example .env
nano .env  # Edit database settings

# Start application
docker-compose up -d

# Check status
docker-compose ps
```

**Step 3: Access Your Application**
- Open browser and go to `http://your-server-ip:5000`
- Application will be running with PostgreSQL database

### Method 2: Traditional Server Installation

**Step 1: Prepare Server**
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib nginx

# Install process manager
sudo npm install -g pm2
```

**Step 2: Setup Database**
```bash
# Switch to postgres user
sudo -u postgres psql

# Create database and user
CREATE DATABASE pockethub;
CREATE USER pockethub_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE pockethub TO pockethub_user;
\q

# Import database schema
sudo -u postgres psql -d pockethub -f init.sql
```

**Step 3: Deploy Application**
```bash
# Extract application files
unzip pockethub-complete.zip
cd pockethub-complete

# Configure environment
cp .env.example .env
nano .env

# Example .env configuration:
NODE_ENV=production
DATABASE_URL=postgresql://pockethub_user:your_secure_password@localhost:5432/pockethub
PORT=5000
SESSION_SECRET=your-super-secret-session-key-here

# Make deployment script executable and run
chmod +x deploy.sh
./deploy.sh
```

**Step 4: Setup Nginx (Optional)**
```bash
# Create Nginx configuration
sudo nano /etc/nginx/sites-available/pockethub

# Add this configuration:
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

# Enable site
sudo ln -s /etc/nginx/sites-available/pockethub /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Cloud Platform Deployment

### Railway
1. Create account at railway.app
2. Connect GitHub repository or upload zip
3. Add PostgreSQL service
4. Set environment variables
5. Deploy automatically

### DigitalOcean App Platform
1. Create new app from GitHub
2. Add managed PostgreSQL database
3. Configure environment variables
4. Deploy with one click

### AWS/Google Cloud/Azure
1. Create virtual machine instance
2. Follow traditional server installation steps
3. Configure security groups/firewall rules
4. Set up domain and SSL certificate

## Environment Configuration

### Required Environment Variables
```env
# Application Environment
NODE_ENV=production

# Database Connection
DATABASE_URL=postgresql://username:password@host:port/database

# Server Configuration
PORT=5000
HOST=0.0.0.0

# Security
SESSION_SECRET=generate-a-strong-random-key
```

### Database URL Examples
```env
# Local PostgreSQL
DATABASE_URL=postgresql://pockethub_user:password@localhost:5432/pockethub

# Cloud Databases
DATABASE_URL=postgresql://user:pass@endpoint.amazonaws.com:5432/pockethub
DATABASE_URL=postgresql://user:pass@endpoint.neon.tech/pockethub
DATABASE_URL=postgresql://user:pass@host.railway.app:port/railway
```

## Application Management

### Using PM2 (Traditional Installation)
```bash
# Start application
pm2 start ecosystem.config.js --env production

# Monitor application
pm2 monit

# View logs
pm2 logs pockethub-app

# Restart application
pm2 restart pockethub-app

# Stop application
pm2 stop pockethub-app

# Auto-start on server reboot
pm2 save
pm2 startup
```

### Using Docker
```bash
# View running containers
docker-compose ps

# View logs
docker-compose logs -f pockethub-app

# Restart application
docker-compose restart

# Stop application
docker-compose down

# Update application
docker-compose pull
docker-compose up -d
```

## Security Best Practices

### 1. Firewall Configuration
```bash
# UFW Firewall setup
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5000/tcp  # If not using Nginx
```

### 2. SSL Certificate (Let's Encrypt)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 3. Database Security
- Use strong passwords
- Enable SSL connections
- Restrict database access
- Regular backups

## Backup Strategy

### Database Backup
```bash
# Create backup
pg_dump -U pockethub_user -h localhost pockethub > backup_$(date +%Y%m%d).sql

# Restore backup
psql -U pockethub_user -h localhost pockethub < backup_20240115.sql

# Automated daily backups
echo "0 2 * * * pg_dump -U pockethub_user pockethub > /backups/pockethub_\$(date +\%Y\%m\%d).sql" | crontab -
```

### Application Backup
```bash
# Backup application files
tar -czf pockethub_backup_$(date +%Y%m%d).tar.gz /path/to/pockethub

# Backup PM2 configuration
pm2 save
```

## Monitoring and Maintenance

### Health Checks
```bash
# Check application health
curl http://localhost:5000/health

# Check database connection
psql -U pockethub_user -h localhost -d pockethub -c "SELECT 1;"

# Check PM2 status
pm2 status
```

### Log Monitoring
```bash
# Application logs
tail -f logs/combined.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# System logs
sudo journalctl -u nginx -f
sudo journalctl -u postgresql -f
```

### Performance Monitoring
```bash
# Server resources
htop
df -h
free -h

# PM2 monitoring
pm2 monit

# Database performance
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity;"
```

## Troubleshooting

### Common Issues

**1. Port 5000 already in use**
```bash
# Find process using port
sudo lsof -i :5000
# Kill process or change PORT in .env
```

**2. Database connection errors**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check database connectivity
psql -U pockethub_user -h localhost -d pockethub
```

**3. Permission errors**
```bash
# Fix file permissions
chmod +x deploy.sh
chown -R $USER:$USER /path/to/pockethub
```

**4. Build failures**
```bash
# Clear cache and rebuild
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Getting Help

**Check logs for errors:**
```bash
# PM2 logs
pm2 logs pockethub-app

# Application logs
tail -f logs/error.log

# System logs
sudo journalctl -xe
```

**Restart services:**
```bash
# Restart application
pm2 restart pockethub-app

# Restart database
sudo systemctl restart postgresql

# Restart web server
sudo systemctl restart nginx
```

## Updates and Maintenance

### Updating Pockethub
1. Backup current installation
2. Download new version
3. Run deployment script
4. Test functionality
5. Monitor for issues

### Regular Maintenance
- Update system packages monthly
- Backup database weekly
- Monitor disk space and performance
- Review security logs
- Update SSL certificates

## Support

Your Pockethub installation includes:
- Complete source code
- Docker configuration
- Deployment scripts
- Database schema
- Production configuration
- Monitoring setup

For technical issues:
1. Check application logs
2. Verify environment configuration
3. Test database connectivity
4. Review server resources

## License

This Pockethub application is provided under MIT License. Free for personal and commercial use.